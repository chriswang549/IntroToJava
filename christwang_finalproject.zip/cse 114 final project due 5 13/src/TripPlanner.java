import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import sun.plugin.javascript.navig.Anchor;

import java.awt.*;
import java.awt.print.Printable;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;


public class TripPlanner extends Application implements EventHandler<ActionEvent> {
    //new tings not categorized yet
    double lat1 = 0;
    double lat2 = 0;
    double long1 = 0;
    double long2 = 0;


    ArrayList<Circle> circles = new ArrayList<>();
    ArrayList<Line> lines = new ArrayList<>();


    static double RADIAN_FACTOR = 180 / Math.PI;
    ObservableList<String> info;
    ObservableList<String> tripList;
    private String total = "";
    private String total2 = "";
    String sort = "";

    int selectedTrip;
    String selectedTripp;
    String selectedPossTrip;

    String selectedTripList;
    int selectedTripListIndex;
    int selectedPossListIndex;
    String[] splittingString;
    Stage stage2;
    ArrayList<String> updatingTripList = new ArrayList<>();
    String deselectTrip;
    Button calculateDistance = new Button("Calculate Distance");
    FileChooser fileChooser = new FileChooser();
    static int mileage = 0;
    Label totalMileage = new Label("Total Mileage: " + mileage);
    static PrintWriter pw = null;
    static PrintWriter pw1 = null;
    static DataOutputStream dos = null;
    GridPane gridPane2;

    Comparator<String> comparator = new Comparator<String>() {
        @Override
        public int compare(String string1, String string2) {
            return string1.compareToIgnoreCase(string2);
        }
    };

    static FileOutputStream fos = null;
    //adding static
    static String city;
    static String state;
    static String latitudeD;
    static String latitudeM;
    static String longitudeD;
    static String longitudeM;
    //editting static
    static String cityE;
    static String stateE;
    static String latitudeDE;
    static String latitudeME;
    static String longitudeDE;
    static String longitudeME;
    // Buttons

    Button newTripButton;
    Button saveTripButton;
    Button loadTripButton;
    Button update;
    Button newTripButtonConfirmOk;
    Button newTripButtonConfirmCancel;
    Button confirmTripName = new Button("Add a new trip");
    Button exit = new Button("Exit to the main stage");

    Button possAdd;
    Button possEdit;
    Button possRemove;
    Button add = new Button("+");
    Button remove = new Button("-");
    Button addToPossibleStops = new Button("+");
    Button removeFromPossibleStops = new Button("-");
    // TextFields
    private TextField newTripName;
    private TextField newCity;
    private TextField newState;
    private TextField newLatDeg;
    private TextField newLatMin;
    private TextField newLongDeg;
    private TextField newLongMin;
    Pane map1;
    // Stages
    private Stage stage0;
    private Stage stage1;

    //Scenes

    private Scene scene0;
    //Images
    private Image map;
    //Panes
    private StackPane stackPane;
    private HBox hBox;
    private VBox vBox1;
    private BorderPane pane;
    //ListViews
    private ListView<String> listView; //poss
    private ListView<String> listViewT;
    //Labels

    private Label label1 = new Label("STOPS IN TRIPLIST");

    public TripPlanner() throws IOException {
    }


    public static void main(String[] args) {
        launch(args);

    }

    ///////////////////////////////////////////////////////////                 SETTING THE STAGE
/////////////////////////////////////////////////////////
    // Border Pane for the Layout
    @Override
    public void start(Stage primaryStage) {
        stage0 = primaryStage;
        primaryStage.setMaximized(true);
        primaryStage.setTitle("Trip Planner - ");
        primaryStage.setMaximized(true);


        pane = new BorderPane(); //layout
        hBox = addHBox();
        pane.setTop(hBox); //TOP
        addMap(); //LEFT


        addStopsInTrip();//RIGHT


        enterNewPossibleTrip();// bottom

        possibleTripsList(); // center

        pane.setStyle("-fx-border-color: red; -fx-background-color: lightgray;");
        scene0 = new Scene(pane);
        primaryStage.setScene(scene0);
        primaryStage.show();


    }

    //          TOP      TOP     TOP        TOP
    public HBox addHBox() {
        HBox hBox = new HBox(5);
        hBox.setPadding(new Insets(9, 12, 15, 12));
        newTripButton = new Button();
        newTripButton.setText("New");
        newTripButton.setPrefSize(80, 10);
        saveTripButton = new Button();
        saveTripButton.setText("Save");
        saveTripButton.setPrefSize(80, 10);
        loadTripButton = new Button();
        loadTripButton.setText("Load");
        loadTripButton.setPrefSize(80, 10);


        newTripButton.setOnAction(this::handle);
        saveTripButton.setOnAction(this::handle2);
        loadTripButton.setOnAction(this::handle3);

        scene0 = new Scene(hBox);
        newTripButton.setStyle("-fx-border-color: blue;");
        saveTripButton.setStyle("-fx-border-color: blue;");
        loadTripButton.setStyle("-fx-border-color: blue;");
        hBox.getChildren().add(newTripButton);
        hBox.getChildren().add(saveTripButton);
        hBox.getChildren().add(loadTripButton);
        hBox.setStyle("-fx-border-color: red;-fx-background-color: #F7FE82;");
        return hBox;
    }


    // LEFT  LEFT    LEFT    LEFT    LEFT    LEFT
    public void addMap() {
        map = new Image("usa_map.jpg");
        ImageView iv = new ImageView();
        //iv.setFitHeight(650);
        iv.setFitWidth(845);
        iv.setPreserveRatio(true);
        System.out.println(iv.getBoundsInParent().getWidth() + "this is width");
        System.out.println(iv.getBoundsInParent().getHeight());

        iv.setImage(map);
        map1 = new Pane();

        map1.getChildren().add(iv);

        //map1.setPadding(new Insets(50, 0, 0, 0));
        pane.setCenter(map1);
    }


    //FIX THIS// RIGHTRIGHT   RIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHTRIGHT
    public VBox addStopsInTrip() {
        tripList = FXCollections.observableArrayList();
        listViewT = new ListView<>(tripList);

        vBox1 = new VBox();

        // HBox buttons = new HBox();
        //        buttons.getChildren().add(add);
        //        buttons.getChildren().add(remove);

        add.setTranslateX(15);
        remove.setTranslateX(15);
        listViewT.setTranslateX(15);
        totalMileage.setTranslateX(15);
        calculateDistance.setTranslateX(15);
        label1.setTranslateX(15);

        vBox1.getChildren().add(listViewT);
        vBox1.getChildren().add(label1);
        vBox1.getChildren().add(add);
        vBox1.getChildren().add(remove);

        //   vBox1.getChildren().add(buttons);
        vBox1.getChildren().add(totalMileage);
        vBox1.getChildren().add(calculateDistance);

        //vBox1.setPadding(new Insets(0, 0, 0, 75));
        pane.setRight(vBox1);
        add.setOnAction(this::handle8);
        remove.setOnAction(this::handle7);
        calculateDistance.setOnAction(this::handle9);

        return vBox1;

    }


    // BOTTOM BOTTOM BOTTOM BOTTOM BOTTOM BOTTOM BOTTOM
    public void enterNewPossibleTrip() {
        newCity = new TextField();
        newState = new TextField();
        newLatDeg = new TextField();
        newLatMin = new TextField();
        newLongDeg = new TextField();
        newLongMin = new TextField();
        addToPossibleStops = new Button("+");
        removeFromPossibleStops = new Button("-");

        GridPane gridPane = new GridPane();
        gridPane.setTranslateX(40);
        gridPane.setTranslateY(-40);
        pane.setBottom(gridPane);

        update = new Button("Update");

        BooleanBinding newCityValid = Bindings.createBooleanBinding(() -> {
            if (newCity.getText().isEmpty() || listView.getSelectionModel().getSelectedIndex() == -1)
                return false;
            return true;
        }, newCity.textProperty());

        BooleanBinding newStateValid = Bindings.createBooleanBinding(() -> {
            if (newState.getText().isEmpty() || listView.getSelectionModel().getSelectedIndex() == -1)
                return false;
            return true;
        }, newState.textProperty());

        BooleanBinding newLatDegValid = Bindings.createBooleanBinding(() -> {
            try {
                if (Integer.parseInt(newLatDeg.getText()) < 25 || Integer.parseInt(newLatDeg.getText()) > 49 || listView.getSelectionModel().getSelectedIndex() == -1)
                    return false;
                return true;
            } catch (Exception e) {
                return false;
            }
        }, newLatDeg.textProperty());

        BooleanBinding newLatMinValid = Bindings.createBooleanBinding(() -> {
            try {
                if (Integer.parseInt(newLatMin.getText()) > 60 || Integer.parseInt(newLatMin.getText()) < 0 || listView.getSelectionModel().getSelectedIndex() == -1)
                    return false;
                return true;
            } catch (Exception e) {
                return false;
            }
        }, newLatMin.textProperty());

        BooleanBinding newLongDegValid = Bindings.createBooleanBinding(() -> {
            try {
                if (Integer.parseInt(newLongDeg.getText()) < 65 || Integer.parseInt(newLongDeg.getText()) > 124 || listView.getSelectionModel().getSelectedIndex() == -1)
                    return false;
                return true;
            } catch (Exception e) {
                return false;
            }
        }, newLongDeg.textProperty());

        BooleanBinding newLongMinValid = Bindings.createBooleanBinding(() -> {
            try {
                if (Integer.parseInt(newLongMin.getText()) > 60 || Integer.parseInt(newLongMin.getText()) < 0 || listView.getSelectionModel().getSelectedIndex() == -1)
                    return false;
                return true;
            } catch (Exception e) {
                return false;
            }
        }, newLongMin.textProperty());

        update.disableProperty().bind(newCityValid.not().or(newStateValid.not()).or(newLatDegValid.not()).or(newLatMinValid.not()).or(
                newLongDegValid.not()).or(newLongMinValid.not())
        );

        addToPossibleStops.setOnAction(this::handle4);
        removeFromPossibleStops.setOnAction(this::handle5);
        update.setOnAction(this::handle6);
        update.setVisible(true);
        gridPane.add(new Label("City:"), 0, 0);
        gridPane.add(newCity, 1, 0);
        gridPane.add(new Label("State:"), 0, 1);
        gridPane.add(newState, 1, 1);
        gridPane.add(new Label("Latitude Degrees:"), 0, 2);
        gridPane.add(newLatDeg, 1, 2);
        gridPane.add(new Label("Latitude Minutes:"), 0, 3);
        gridPane.add(newLatMin, 1, 3);
        gridPane.add(new Label("Longitude Degrees"), 0, 4);
        gridPane.add(newLongDeg, 1, 4);
        gridPane.add(new Label("Longitude Minutes"), 0, 5);
        gridPane.add(newLongMin, 1, 5);
        gridPane.add(update, 2, 6);
        gridPane.add(addToPossibleStops, 2, 7);
        gridPane.add(removeFromPossibleStops, 3, 7);
    }


    public void possibleTripsList() {


        info = FXCollections.observableArrayList(
                "Austin,TX,30°,16',97°,44'",
                "Boston,MA,42°,21',71°,3'",
                "Dallas,TX,32°,46',96°,47'",
                "Denver,CO,39°,44',104°,59'",
                "El Paso,TX,31°,46',106°,27'",
                "Houston,TX,29°,45',95°,22'",
                "Indianapolis,IN,39°,46',86°,9'",
                "Jacksonville,FL,30°,19',81°,39'",
                "Los Angeles,CA,34°,3',118°,14'",
                "New Orleans,LA,29°,56',90°,4'"
        );


        listView = new ListView<>();
        SortedList sortedList = new SortedList(info);
        sortedList.setComparator(new Comparator<String>() {
            @Override
            public int compare(String string1, String string2) {
                return string1.compareToIgnoreCase(string2);
            }
        });
        listView.setItems(sortedList);
        pane.setAlignment(listView, Pos.BOTTOM_LEFT);
        pane.setMargin(listView, new Insets(0, 100, 100, 12));
        pane.setLeft(listView);
        listView.setOnMouseClicked(mouseEvent -> {
            if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
                selectedTripp = listView.getSelectionModel().getSelectedItem();
                selectedPossListIndex = listView.getSelectionModel().getSelectedIndex();
                if (selectedTripp != null) {
                    splittingString = selectedTripp.split(","); // my string array split by ,
                    city = splittingString[0];
                    state = splittingString[1];
                    latitudeD = splittingString[2].replace("°", "");
                    latitudeM = splittingString[3].replace("'", "");
                    longitudeD = splittingString[4].replace("°", "");
                    longitudeM = splittingString[5].replace("'", "");

                    newCity.setText(city);
                    newState.setText(state);
                    newLatDeg.setText(latitudeD);
                    newLatMin.setText(latitudeM);
                    newLongDeg.setText(longitudeD);
                    newLongMin.setText(longitudeM);
                    //update.setDisable(false);
                }
            }

            if (mouseEvent.getClickCount() == 2) {
                selectedTripp = null;
                listView.getSelectionModel().clearSelection(selectedPossListIndex);
                newCity.clear();
                newState.clear();
                newLatDeg.clear();
                newLatMin.clear();
                newLongDeg.clear();
                newLongMin.clear();
                //update.setDisable(true);

            }
        });
    }

    // void methods
    public void addPossibleStops() {
        //changed string city to global city
        city = newCity.getText();
        state = newState.getText();
        latitudeD = newLatDeg.getText();
        latitudeM = newLatMin.getText();
        longitudeD = newLongDeg.getText();
        longitudeM = newLongMin.getText();
        Alert alert10 = new Alert(Alert.AlertType.WARNING);
        String city1 = "";
        Boolean found = false;
        for (int i = 0; i < info.size(); i++) {
            city1 = info.get(i).split(",")[0];
            if (city1.equalsIgnoreCase(city)) {

                alert10 = new Alert(Alert.AlertType.WARNING);
                alert10.setTitle("Adding wrong values");
                alert10.setHeaderText("Look, a Warning Dialog");
                alert10.setContentText("You have a possible stop with the same city name!"
                );

                alert10.showAndWait();
                found = true;
                break;
            }
        }
        if (!found) {
            try {

                if ((Integer.parseInt(latitudeD) < 25 || Integer.parseInt(latitudeD) > 49) ||
                        (Integer.parseInt(latitudeM) < 0 || Integer.parseInt(latitudeM) > 60) ||
                        (Integer.parseInt(longitudeD) < 65 || Integer.parseInt(longitudeD) > 124) ||
                        (Integer.parseInt(longitudeM) < 0 || Integer.parseInt(longitudeM) > 60)) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Adding wrong values");
                    alert.setHeaderText("Look, a Warning Dialog");
                    alert.setContentText("Latitude Degrees 25-49 inclusive exclusive \n" +
                            "IF YOU WANT 50 degrees, 49 Degrees and 60 minutes = 50 degrees! \n " +
                            "Latitude Minutes 0-60 inclusive \n " +
                            "Longitude Degrees 65-124 inclusive exclusive \n" +
                            "IF YOU WANT 125 degrees, 124 Degrees and 60 minutes = 125 degrees!\n" +
                            "Longitude Minutes 0-60 inclusive \n"
                    );

                    alert.showAndWait();

                } else {
                    total += (city + "," + state + "," + latitudeD + "°," + latitudeM + "'," + longitudeD + "°," + longitudeM + "'");
                    info.add(total);
                    info.sort(comparator);
                    Alert alert5 = new Alert(Alert.AlertType.INFORMATION);
                    alert5.setTitle("ADDING A TRIP TO POSSIBLE TRIPS");
                    alert5.setHeaderText("Look, an Information Dialog");
                    alert5.setContentText("You should have successfully added to possible trips! \n");
                    alert5.showAndWait();
                    total = "";


                }
            } catch (NumberFormatException a) {


            }
        }


    }

    public void editPossTrips() {

        listView.setOnMouseClicked(mouseEvent -> {
                    if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
                        selectedTripp = listView.getSelectionModel().getSelectedItem();
                        String posstrip = selectedTripp;
                        selectedPossListIndex = listView.getSelectionModel().getSelectedIndex();
                        int index = selectedPossListIndex;

                        newCity.setText(city);
                        newState.setText(state);
                        newLatDeg.setText(latitudeD);
                        newLatMin.setText(latitudeM);
                        newLongDeg.setText(longitudeD);
                        newLongMin.setText(longitudeM);

                        newCity.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                            // ...
                        });


                        newState.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                            // ...
                        });
                        newLatDeg.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                            // ...
                        });
                        newLatMin.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                            // ...
                        });
                        newLongDeg.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                            // ...
                        });
                        newLongMin.textProperty().addListener((obs, oldText, newText) -> {
                            System.out.println("Text changed from " + oldText + " to " + newText);
                            update.setVisible(true);
                        });
                    }
                    if (mouseEvent.getClickCount() == 2) {
                        selectedTripp = listView.getSelectionModel().getSelectedItem();
                        listViewT.getSelectionModel().clearSelection(selectedTripListIndex);
                    }

                }
        );

    }


    public void removePossibleStops() {
        selectedTrip = listView.getSelectionModel().getSelectedIndex();
        System.out.println(selectedTrip + "this is selected trip index from poss stops");
        if (selectedTrip != -1) {
            System.out.println(info + "this is observable list for poss trips");
            info.remove(selectedTrip);
            info.sort(comparator);
            //listView.getItems().remove(selectedTrip);
        }
    }

    public void addTrip() {
        listViewT.setOnMouseClicked(mouseEvent -> {
            if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {

                selectedTripp = listView.getSelectionModel().getSelectedItem();
                selectedTripList = listViewT.getSelectionModel().getSelectedItem();
                selectedTripListIndex = listViewT.getSelectionModel().getSelectedIndex();
                if (mouseEvent.getClickCount() == 2) {
                    selectedTripp = listView.getSelectionModel().getSelectedItem();
                    listViewT.getSelectionModel().clearSelection(selectedTripListIndex);
                }
            }
        });

        selectedTripp = listView.getSelectionModel().getSelectedItem();
        selectedTripList = listViewT.getSelectionModel().getSelectedItem();

        selectedTripListIndex = listViewT.getSelectionModel().getSelectedIndex();

        if (selectedTripListIndex != -1) {
            tripList.add(selectedTripListIndex + 1, selectedTripp);
            String[] the = selectedTripp.split(",");
            mapCircleLines(the[2], the[3], the[4], the[5], selectedTripListIndex + 1);
        } else {

            if (selectedTripp != null) {
                tripList.add(0, selectedTripp);
                String[] the = selectedTripp.split(",");
                mapCircleLines(the[2], the[3], the[4], the[5], 0);
            }
        }
    }

    public void removeTrip() {
        selectedTripListIndex = listViewT.getSelectionModel().getSelectedIndex();
        if (selectedTripListIndex != -1) {
            listViewT.getItems().remove(selectedTripListIndex);
            Circle removeCircle = circles.remove(selectedTripListIndex);
            map1.getChildren().remove(removeCircle);

            for (int i = lines.size() - 1; i >= 0; i--) {
                map1.getChildren().remove(lines.get(i));
            }
            if (lines.size() >= 1)
                lines.remove(lines.size() - 1);
            for (int i = 0; i < lines.size(); i++) {
                lines.get(i).setStartX(circles.get(i).getCenterX());
                lines.get(i).setStartY(circles.get(i).getCenterY());
                lines.get(i).setEndX(circles.get(i + 1).getCenterX());
                lines.get(i).setEndY(circles.get(i + 1).getCenterY());
                map1.getChildren().add(lines.get(i));
            }
        }
    }

    public void loadFile() {
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File("C:\\Users\\Chris Wangs Surface3\\Desktop\\CSE 114"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Binary File", ".bin"));

        File loadFile = fc.showOpenDialog(null);
        BufferedReader reader;

        if (loadFile != null) {
            try {
                reader = new BufferedReader(new FileReader(loadFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    listViewT.getItems().add(line);
                }
            } catch (Exception e) {

            }
        } else {
            System.out.println("file is not valid");
        }
        map1.getChildren().remove(circles);
        map1.getChildren().remove(lines);

    }


    ///////////////////////////////////// HANDLERS
    public void handle9(ActionEvent calculateDaDistance) {
        if (calculateDaDistance.getSource() == calculateDistance) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to calculate");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {

                gettingLatLong();


            } else {

            }
        }
    }


    public void handle8(ActionEvent tripAdd) {
        if (tripAdd.getSource() == add) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to add to triplist");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                addTrip();


            } else {

            }
        }
    }


    public void handle7(ActionEvent tripRemove) {
        if (tripRemove.getSource() == remove) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to remove from triplist");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                removeTrip();


            } else {

            }
        }
    }

    public void handle6(ActionEvent updateButton) {
        if (updateButton.getSource() == update) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to update your selection in possible trips?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                selectedTrip = listView.getSelectionModel().getSelectedIndex();
                if (selectedTrip >= 0) {
                    info.remove(selectedTrip);

                    addPossibleStops();
                    Alert alert3 = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText("Look, an Information Dialog");
                    alert.setContentText("You should have updated a stop with valid inputs! ");

                    alert.showAndWait();
                }
            }
        }
    }


    public void handle5(ActionEvent possRemove) {
        if (possRemove.getSource() == removeFromPossibleStops) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to remove from possible trips");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                removePossibleStops();
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Look, an Information Dialog");
                alert.setContentText("You should have removed from possible stops successfully");

                alert.showAndWait();


            } else {

            }
        }
    }

    public void handle4(ActionEvent possAdd) {
        if (possAdd.getSource() == addToPossibleStops) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to add to possible trips");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                addPossibleStops();
                newCity.clear();
                newState.clear();
                newLatDeg.clear();
                newLatMin.clear();
                newLongDeg.clear();
                newLongMin.clear();


            } else {

            }

        }
    }


    public void handle3(ActionEvent load) {
        if (load.getSource() == loadTripButton) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Load confirmation");
            alert.setHeaderText("Are you sure you want to load?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                loadFile();
                mileage = 0;
                totalMileage.setText("Total Mileage: " + mileage);

            } else {

            }
        }
    }

    public void handle2(ActionEvent save) {


        if (save.getSource() == saveTripButton) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Save confirmation");
            alert.setHeaderText("Are you sure you want to save?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                fileChooser.setTitle("Save Dialog");
                if (newTripName != null) {
                    fileChooser.setInitialFileName(newTripName.getText());
                } else {
                    System.out.println("Create a new file");
                }
                fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Text File", "*.txt"),
                        new FileChooser.ExtensionFilter("Binary File", ".bin"));
                File createFile = fileChooser.showSaveDialog(stage0);

                if (createFile != null) {
                    System.out.println("FILE CREATED ON SAVE");
                    FileWriter savefw = null;
                    try {
                        savefw = new FileWriter(createFile);
                    } catch (IOException e) {
                    }
                    pw = new PrintWriter(savefw);
                    for (int i = 0; i < listViewT.getItems().size(); i++) {
                        pw.write(listViewT.getItems().get(i) + "\n");
                    }
                    pw.close();
                    try {
                        savefw.close();
                    } catch (IOException e) {
                    }
                } else {
                    System.out.println("Some issue creating save file");
                }

            } else {

            }
        }
    }

    public void handle1(ActionEvent event1) {
        if (event1.getSource() == confirmTripName) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("You entered the trip");
            alert.setHeaderText("Trip name is set");
            stage0.setTitle("Trip Planner - " + newTripName.getText());
            tripList.clear();
            alert.showAndWait();
            stage1.hide();

            //go back to the main stage
        } else if (event1.getSource() == exit) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Back to the main stage");
            alert.setHeaderText("You quit");
            alert.showAndWait();
            stage1.hide();

        }
    }

    @Override
    public void handle(ActionEvent event) {
        if (event.getSource() == newTripButton) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText("Are you sure you want to create a new trip?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                stage1 = new Stage();


                stage1.setTitle("Enter a trip name");
                mileage = 0;
                totalMileage.setText("Total Mileage: " + mileage);

                newTripName = new TextField();

                GridPane gridPane = new GridPane();
                gridPane.setHgap(5);
                gridPane.setVgap(5);
                //gridPane.add(new Label("Trip Name:"), 0, 0);
                gridPane.add(newTripName, 1, 0);
                Scene scene1 = new Scene(gridPane);
                gridPane.getChildren().add(confirmTripName);

                // gridPane.getChildren().add(exit);
                // GridPane.setConstraints(exit, 1, 2);
                confirmTripName.setOnAction(this::handle1);
                //exit.setOnAction(this::handle1);


                map1.getChildren().removeAll(circles);
                map1.getChildren().removeAll(lines);

                stage1.setScene(scene1);
                stage1.show();

                // ... user chose OK
            } else {
                // ... user chose CANCEL or closed the dialog
            }
        }


    }

    private void gettingLatLong() {
        String city1;
        String city2;
        mileage = 0;
        if (tripList.size() > 0) {
            for (int i = 0; i < tripList.size() - 1; i++) {
                if (tripList.size() == 1) {
                    totalMileage.setText("Total Mileage of 1 city: " + mileage);

                } else if (tripList.size() == 2) {
                    city1 = tripList.get(0).split(",")[0];
                    System.out.println(city1 + "this is city1");
                    city2 = tripList.get(1).split(",")[0];
                    System.out.println(city2 + "this is city2");
                    if (city1.equalsIgnoreCase(city2)) {
                        totalMileage.setText("Total Mileage of 2 cities: " + mileage);
                        break;
                    } else {

                        int lat1Degrees = Integer.parseInt(tripList.get(i).split(",")[2].trim().replace("°", ""));
                        System.out.println(lat1Degrees + " lat1 degrees");

                        int lat1Minutes = Integer.parseInt(tripList.get(i).split(",")[3].trim().replace("'", ""));

                        System.out.println(lat1Minutes + " lat1 min");
                        int long1Degrees = Integer.parseInt(tripList.get(i).split(",")[4].trim().replace("°", ""));
                        System.out.println(long1Degrees);
                        int long1Minutes = Integer.parseInt(tripList.get(i).split(",")[5].trim().replace("'", ""));
                        System.out.println(long1Minutes);

                        System.out.println(" Seperation between lat 1 and lat 2");
                        int lat2Degrees = Integer.parseInt(tripList.get(i + 1).split(",")[2].trim().replace("°", ""));
                        System.out.println(lat2Degrees);
                        int lat2Minutes = Integer.parseInt(tripList.get(i + 1).split(",")[3].trim().replace("'", ""));
                        System.out.println(lat2Minutes);
                        int long2Degrees = Integer.parseInt(tripList.get(i + 1).split(",")[4].trim().replace("°", ""));
                        System.out.println(long2Degrees);
                        int long2Minutes = Integer.parseInt(tripList.get(i + 1).split(",")[5].trim().replace("'", ""));
                        System.out.println(long2Minutes);

                        mileage += calculateDistance(lat1Degrees, lat1Minutes, long1Degrees, long1Minutes,
                                lat2Degrees, lat2Minutes, long2Degrees, long2Minutes);

                        totalMileage.setText("Total Mileage of 2 cities: " + mileage);

                    }

                } else {
                    if (i == tripList.size()) {
                        totalMileage.setText("Total Mileage: " + mileage);
                        break;
                    }
                    city1 = tripList.get(i).split(",")[0];
                    System.out.println(city1 + "this is city1");
                    city2 = tripList.get(i + 1).split(",")[0];
                    System.out.println(city2 + "this is city2");
                    if (city1.equalsIgnoreCase(city2)) {
                        mileage += 0;
                    } else {
                        int lat1Degrees = Integer.parseInt(tripList.get(i).split(",")[2].trim().replace("°", ""));
                        System.out.println(lat1Degrees + " lat1 degrees");

                        int lat1Minutes = Integer.parseInt(tripList.get(i).split(",")[3].trim().replace("'", ""));

                        System.out.println(lat1Minutes + " lat1 min");
                        int long1Degrees = Integer.parseInt(tripList.get(i).split(",")[4].trim().replace("°", ""));
                        System.out.println(long1Degrees);
                        int long1Minutes = Integer.parseInt(tripList.get(i).split(",")[5].trim().replace("'", ""));
                        System.out.println(long1Minutes);

                        System.out.println(" Seperation between lat 1 and lat 2");
                        int lat2Degrees = Integer.parseInt(tripList.get(i + 1).split(",")[2].trim().replace("°", ""));
                        System.out.println(lat2Degrees);
                        int lat2Minutes = Integer.parseInt(tripList.get(i + 1).split(",")[3].trim().replace("'", ""));
                        System.out.println(lat2Minutes);
                        int long2Degrees = Integer.parseInt(tripList.get(i + 1).split(",")[4].trim().replace("°", ""));
                        System.out.println(long2Degrees);
                        int long2Minutes = Integer.parseInt(tripList.get(i + 1).split(",")[5].trim().replace("'", ""));
                        System.out.println(long2Minutes);

                        mileage += calculateDistance(lat1Degrees, lat1Minutes, long1Degrees, long1Minutes,
                                lat2Degrees, lat2Minutes, long2Degrees, long2Minutes);

                        totalMileage.setText("Total Mileage:" + mileage);

                        System.out.println(mileage);
                    }
                }
            }
        }
        System.out.println("Total distance is displayed!");
    }


// if ( i == tripList.size()){
//                        break;

    //static double
    private double calculateDistance(double lat1Degrees, double lat1Minutes,
                                     double lat2Degrees, double lat2Minutes,
                                     double long1Degrees, double long1Minutes, double long2Degrees, double long2Minutes) {

        double RADIAN_FACTOR = 180 / Math.PI;
        // double lat1 = 0;  // Multiple by direction 1 or -2
        //        double lat2 = 0;
        //        double long1 = 0;
        //        double long2 = 0;
        int EARTH_RADIUS = 6371;


        if (lat1Degrees < 0) {
            lat1 = (-lat1Degrees + lat1Minutes / 60) * (-1);
        } else {
            lat1 = lat1Degrees + lat1Minutes / 60;
        }
        if (lat2Degrees < 0) {
            lat2 = (-lat2Degrees + lat2Minutes / 60) * (-1);

        } else {
            lat2 = lat2Degrees + lat2Minutes / 60;
        }
        if (long1Degrees < 0) {
            long1 = (-long1Degrees + long1Minutes / 60) * (-1);
        } else {
            long1 = (long1Degrees + long1Minutes / 60);
        }
        if (long2Degrees < 0) {
            long2 = (-long2Degrees + long2Minutes / 60) * (-1);
        } else {
            long2 = (long2Degrees + long2Minutes / 60);
        }


        double x = (Math.sin(lat1 / RADIAN_FACTOR) * Math.sin(lat2 / RADIAN_FACTOR))
                + (Math.cos(lat1 / RADIAN_FACTOR)
                * Math.cos(lat2 / RADIAN_FACTOR)
                * Math.cos((long2 / RADIAN_FACTOR) - (long1 / RADIAN_FACTOR)));

        double distance = EARTH_RADIUS * Math.atan((Math.sqrt(1 - Math.pow(x, 2)) / x));
        return distance;
    }

    public void mapCircleLines(String latD, String latM, String longD, String longM, int index) {


        int lat1Degrees = Integer.parseInt(latD.trim().replace("°", ""));
        int lat1Minutes = Integer.parseInt(latM.trim().replace("'", ""));
        System.out.println(lat1Degrees);
        int long1Degrees = Integer.parseInt(longD.trim().replace("°", ""));

        int long1Minutes = Integer.parseInt(longM.trim().replace("'", ""));
        double lat1 = (double) (lat1Degrees + lat1Minutes / 60);
        double long1 = (double) (long1Degrees + long1Minutes / 60);

        //double width = map1.getWidth();
        //double height = map1.getHeight();
        ImageView iv = (ImageView) map1.getChildren().get(0);
        double width = iv.boundsInParentProperty().get().getWidth();
        double height = iv.boundsInParentProperty().get().getHeight();

        double x = 0;
        double y = 0;

        double pixelsPerlat = (height / (50 - 25));
        y = (height - ((lat1 - 25) * pixelsPerlat));

        double pixelsPerLong = (width / (125 - 65));
        x = (width - ((long1 - 65) * pixelsPerLong));

        Circle circle = new Circle();
        Line line = new Line();

        circle.setCenterX(x);
        circle.setCenterY(y);
        circle.setRadius(3);
        circle.setFill(Color.WHITE);
        circle.setStroke(Color.BLACK);
        map1.getChildren().add(circle);

        circles.add(index, circle);
        System.out.println(circles);
        if (circles.size() > 1) {
            line.setStroke(Color.WHITE);
            line.setFill(Color.WHITE);
            lines.add(line);
            for (int i = 0; i < lines.size(); i++) {
                map1.getChildren().remove(lines.get(i));
                lines.get(i).setStartX(circles.get(i).getCenterX());
                lines.get(i).setStartY(circles.get(i).getCenterY());
                lines.get(i).setEndX(circles.get(i + 1).getCenterX());
                lines.get(i).setEndY(circles.get(i + 1).getCenterY());
                map1.getChildren().add(lines.get(i));
            }
        }

    }
}