package part1;

import java.awt.*;

public class SlowLifeGivingRoundRect extends FroggerSceneObject {
    // THIS IS USED FOR AI
    private int counter;

    /**
     * This constructor initializes all instance
     * variables.
     */
    public SlowLifeGivingRoundRect(
            int initX, int initY,
            int initVelocityX,
            int initVelocityY,
            int initWidth, int initHeight,
            Color initColor) {
        // USE THE FroggerSceneObject CONSTRUCTOR
        super(initX, initY, -1, initVelocityY, initWidth, initHeight,
                initColor);

        // RESET THE COUNTER
        counter = 0;
    }
    public void move() {
        int x = getVelocityX();
        if (x<-50){
            this.setVelocityX(-1);
        }


    }

      //setVelocityX(1);
        //        int x = getVelocityX();
        //        if (x < 50) {
        //            x++;
        //            if (x>50)
        //                setVelocityX(1);
        //
        //
        //        }}

    public void render(Graphics g) {
        g.setColor(getColor());
        g.fillRoundRect(getX(), getY(), getWidth(), getHeight(),150,93);
    }
    public void respondToCollision(FroggerSceneObject frogger) {
        frogger.decLife(-5);
        this.setVelocityX(this.getVelocityX() - 1);
    }
}
