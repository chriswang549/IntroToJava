package part1;

import java.awt.*;

public class ChargingEvilRect extends FroggerSceneObject{


        // THIS IS USED FOR AI
        private int counter;
        private int maxvelocity;

        /**
         * This constructor initializes all instance
         * variables.
         */
        public ChargingEvilRect(
                int initX, int initY,
                int initVelocityX,
                int initVelocityY,
                int initWidth, int initHeight,
                Color initColor) {
            // USE THE FroggerSceneObject CONSTRUCTOR
            super(initX, initY, initVelocityX, initVelocityY, initWidth, initHeight,
                    initColor);

            // RESET THE COUNTER
            counter = 0;
            maxvelocity = (int)((Math.random()*101)+50) ;
        }
        public void move() {



                if (counter < maxvelocity){
                    ++counter;
                    setVelocityX(-counter);


                }else {
                    setVelocityX(0);
                    counter=0;
                    maxvelocity = (int)((Math.random()*101)+50) ;


            }
        }











        public void render(Graphics g) {
            g.setColor(getColor());
            g.fillRect(getX(), getY(), getWidth(), getHeight());
        }
        public void respondToCollision(FroggerSceneObject frogger) {
            frogger.decLife(5);
        }
    }


