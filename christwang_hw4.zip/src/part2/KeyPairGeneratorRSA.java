package part2;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Random;


public class KeyPairGeneratorRSA {
    private int initKeySize;
    private int bitLength;
    private int certainity;
    private Random rnd;

    public KeyPairGeneratorRSA(int initKeySize) {
        this.initKeySize = initKeySize;
        this.bitLength = 1024;
    }

    public KeyPairRSA generateKeyPair() {
        Random rmd = new SecureRandom();
        BigInteger newP = new BigInteger(bitLength, 50, rmd);
        BigInteger newQ = new BigInteger(bitLength, 50, rmd);
        BigInteger newN = newP.multiply(newQ);
        BigInteger one = new BigInteger("1");
        BigInteger negativeOne = new BigInteger("-1");
        BigInteger formula = newP.subtract(one).multiply(newQ.subtract(one));
        BigInteger newE = new BigInteger(bitLength, 50, rmd);
        BigInteger newD = newE.modPow(negativeOne, formula);
        return new KeyPairRSA(newD, newE, newN);

    }
}