package part2;

import java.math.BigInteger;
import java.security.SecureRandom;


public class PublicKeyRSA extends KeyRSA {
    private BigInteger e;

    public PublicKeyRSA(BigInteger randomE, BigInteger randomN) {
        super(randomN);
        this.e = randomE;
    }

    public BigInteger getE() {
        return e;
    }


    public String toString() {
        return ("KU:{" + e + "," + getN() + "}");


    }

    public BigInteger encrypt(String plaintext) {
        BigInteger textBytes = new BigInteger(plaintext.getBytes());
        System.out.println(textBytes);
        int compare = (textBytes.compareTo(getN()));
        if (compare == 1) {
            BigInteger text = new BigInteger("PLAINTEXT MESSAGE TOO BIG");
            return (text);

        } else {
            /*
            BigInteger cipherText = textBytes.modPow(new BigInteger("2651120363"), new BigInteger("9374104986070696169"));
            return cipherText;
*/


            BigInteger cipherText = textBytes.modPow(e, getN());
            return cipherText;
        }
    }
}








