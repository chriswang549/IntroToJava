package part2;

import java.math.BigInteger;

public abstract class KeyRSA {
    private BigInteger n;


    public KeyRSA(BigInteger randomN) {
        this.n = randomN;

    }

    public BigInteger getN() {
        return this.n;
    }
}