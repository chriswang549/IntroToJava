package part2;

import java.math.BigInteger;

public class PrivateKeyRSA extends KeyRSA {
    private BigInteger d;

    public PrivateKeyRSA(BigInteger randomD, BigInteger randomN) {
        super(randomN);
        this.d = randomD;
    }

    public String toString() {
        return ("KR:{" + d + ", " + this.getN() + "}");
    }
    public String decrypt(BigInteger cipherInt){
        /*
        BigInteger decryptionFormula = cipherInt.modPow(new BigInteger("7553743486252930067"), new BigInteger("9374104986070696169"));
        String plainText = new String(decryptionFormula.toByteArray());
        return plainText;
*/

        BigInteger decryptionFormula = cipherInt.modPow(d, getN());
        String plainText = new String(decryptionFormula.toByteArray());
        return plainText;

    }
}