package part2;

import java.math.BigInteger;

public class KeyPairRSA extends KeyRSA {

    private PublicKeyRSA publicKey;
    private PrivateKeyRSA privateKey;

    public KeyPairRSA(BigInteger d, BigInteger e, BigInteger n) {
        super(n);
        this.publicKey = new PublicKeyRSA(e, n);
        this.privateKey = new PrivateKeyRSA(d, n);
    }

    public PrivateKeyRSA getPrivateKey() {
        return this.privateKey;
    }

    public PublicKeyRSA getPublicKey() {
        return this.publicKey;
    }
    public String the(){
        String x = publicKey.toString();
        String y = privateKey.toString();
        return (x + y);
    }

}
//