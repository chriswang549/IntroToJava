package part1;


public class Casino {
    private String privateCasinoName;
    private int start;
    private int end;
    private PairOfDice Krawtz;

    // constructor
    public Casino(String publicCasinoName, int endCB) {
        privateCasinoName = publicCasinoName;


        start = endCB;
        end = endCB;
        Krawtz = new PairOfDice();
    }

    //getters
    public String getCasinoName() {
        return privateCasinoName;
    }

    public int getStartCasinoBalance() {
        return start;
    }

    public int getEndCasinoBalance() {
        return end;
    }

    public void setCasinoBalance(int endDB) {

        end = endDB;


    }

    public double getCasinoOverallStats() {
        return ((end - start) * (100.0) / (start));
    }

    public double CasinoFactor() {
        if (end > 1000000) {
            return 0.005;
        } else
            return 0.01;
    }

    public void DiceRollOdds(int rolls) {
        System.out.println("2:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + ((3 * CasinoFactor())), rolls)) + " to 1"));
        System.out.println("3:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + ((2 * CasinoFactor())), rolls)) + " to 1"));
        System.out.println("4:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + CasinoFactor(), rolls)) + " to 1"));
        System.out.println("5:\t\t9 to 1 ");
        System.out.println("6:\t\t" + String.valueOf((int) (7.2 * Math.pow(1.0 - CasinoFactor(), rolls)) + " to 1"));
        System.out.println("7:\t\t" + String.valueOf((int) (6.0 * Math.pow(1.0 - ((2 * CasinoFactor())), rolls)) + " to 1"));
        System.out.println("8:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 - CasinoFactor(), rolls)) + " to 1"));
        System.out.println("9:\t\t9 to 1 ");
        System.out.println("10:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + CasinoFactor(), rolls)) + " to 1"));
        System.out.println("11:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + ((2 * CasinoFactor())), rolls)) + " to 1"));
        System.out.println("12:\t\t" + String.valueOf((int) (36 * Math.pow(1.0 + ((3 * CasinoFactor())), rolls)) + " to 1"));
    }

    public void roll() {
        Krawtz.rollDice();
    }

    public int faceValue() {
        return Krawtz.getTotal();
    }

    public String toString() {
        return "The casino's bank account is now at " + this.getEndCasinoBalance() + "\n" + "The casino's bank account is down " + this.getCasinoOverallStats() + " % ";
    }
}