package part1;

import java.util.Scanner;

public class Gambler {
    private String privateGamblerName;
    private int end;
    private int start;
    //private int difference;

    //constructor
    //name
    //balance after betting
    //starting balance
    public Gambler(String publicGamblerName, int endB) {
        privateGamblerName = publicGamblerName;
        end = endB;
        start = endB;
       // difference = end - start;


    }

    public double getOverallStats() {

        return ((end-start)*(100.0)/(start));
    }
    //public int theDifference(){
       // String Andy = "";
        //if (difference >= 0 ) {
          //  System.out.println("You have enough money to bet");
          //  return (end - start);
       // }else{
       //     System.out.println("You need more in your balance to bet");
       // }
      //     return -1;
  //  }




    //getters
    // getname() returns the name of my Gambler
    // (getbalance() returns starting balance
    public String getName() {
        return privateGamblerName;
    }
    public int getStartBalance(){
        return start;
    }
    public int getEndBalance() {
        return end;

    }
    //setters
    //

    public void setBalance(int endB) {
        end = endB;
    }




    public String toString() {
        String stat = "";
        if (getOverallStats() > 0) {
            stat = "\nYou're STEALING MY MONEY";
        }
        else if (getOverallStats() < 0) {
            stat = "\nYou're losing money. Play again? ";
        }


        else {
            stat = "\nAre you even playing? ";
        }
        return (privateGamblerName + " has an account balance of " + getEndBalance() + " and percent gain/loss is " + getOverallStats() + "%." + stat);
    }

}





















