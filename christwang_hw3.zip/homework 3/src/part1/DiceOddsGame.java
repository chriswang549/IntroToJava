package part1;


import java.util.Scanner;

public class DiceOddsGame {
    public static void main(String[] args) {
        boolean runCode = true;
        Gambler privateGamblerName = null;
        int startingCB = 1000000;
        Casino casino = new Casino("Christopher Wang's Casino", startingCB);
        Scanner s = new Scanner(System.in);
        System.out.println("Welcome To " + casino.getCasinoName());
        //intro stuff

        while (runCode) {
            runMainMenu();
            String userSelection = s.nextLine();

            if (userSelection.equals("1")) {
                System.out.println("****************************************************");
                System.out.println("** WELCOME TO " + casino.getCasinoName() + "**");
                System.out.println("** REMEMBER TO HAVE FUN AND KEEP PLAYING **");
                System.out.println("****************************************************");
                privateGamblerName = createGambler(privateGamblerName, s);
                s.nextLine();
            } else if (userSelection.equals("2")) {
                if (privateGamblerName != null) {
                    boolean keepPlaying = true;
                    while (keepPlaying) {
                        int rollsAmount = 0;
                        if (privateGamblerName == null)
                            System.out.println("You must setup a Gambling Account before you start playing!");
                        else {
                            System.out.println("How many rolls would you like to bet? " + "( 1 - 50 )");
                            rollsAmount = s.nextInt();
                            while (rollsAmount > 50 || rollsAmount < 1) {
                                System.out.println("Pick a number between 1-50");
                                System.out.println("How many rolls would you like to bet? " + "( 1 - 50 )");
                                rollsAmount = s.nextInt();
                            }
                            casino.DiceRollOdds(rollsAmount);

                        }
                        System.out.println(privateGamblerName.getName() + " what roll would you like to bet on? (2 - 12) ");
                        int rollBet = s.nextInt();

                        while (rollBet > 12 || rollBet < 2) {
                            System.out.println("Bet on a roll 2 - 12 ");
                            System.out.println(privateGamblerName.getName() + " what roll would you like to bet on? (2 - 12) ");
                            rollBet = s.nextInt();

                        }
                        System.out.println(privateGamblerName.getName() + " enter your bet (min $10, max $100000): ");

                        int betAmount = s.nextInt();
                        while (betAmount < 10 || betAmount > 100000) {
                            System.out.println(" You need to bet $10 or more but less than $100000");
                            System.out.println(privateGamblerName.getName() + " enter your bet (min $10, max $100000): ");
                            betAmount = s.nextInt();
                        }
                        if (privateGamblerName.getEndBalance() - betAmount < 0) {
                            System.out.println("You bet " + betAmount + " but you have " + privateGamblerName.getEndBalance());
                        } else {
                            // processing the menu
                            int[] rollvalues = new int[11]; // create empty array of 11 index of 0-10
                            for (int i = 0; i < rollsAmount; i++) { //for each index as it is less than the # of rolls increment by 1
                                casino.roll(); // roll to get a random value 1-6
                                int value = casino.faceValue(); // roll a pair of dice and get the total value 2-12
                                rollvalues[value - 2]++; // our empty array has index of value -2 increment by 1. EX 2 would be 0 and 3 would be 1
                            }
                            int highestDice = 2; //  dice value starting at  2 goes to 12
                            int numRolls = rollvalues[0]; // the number of rolls is equal to our created array starting index 0 which is 2
                            int secondHighestDice = 3;
                            int numRolls1 = rollvalues[1];
                            if (numRolls1 > numRolls) {
                                int temp = numRolls;
                                numRolls = numRolls1;
                                numRolls1 = temp;
                                temp = highestDice;
                                highestDice = secondHighestDice;
                                secondHighestDice = temp;
                            }

                            System.out.println("RESULTS OF " + rollsAmount + " ROLL(S):"); // list of 2-12 values and  roll amount per
                            for (int i = 2; i < rollvalues.length; i++) { // for each index of values 2-12
                                if (rollvalues[i] > numRolls) { //if number at index in array is greater than number of rolls each value
                                    secondHighestDice = highestDice;
                                    numRolls1 = numRolls;
                                    numRolls = rollvalues[i]; // the amount of rolls = value at each index
                                    highestDice = i + 2; // index of + 2 because 2-12 ex 0+2 = 2 , 1+2 = 3
                                } else if (rollvalues[i] > numRolls1) {
                                    secondHighestDice = i + 2;
                                    numRolls1 = rollvalues[i];
                                }
                                System.out.println(i + 2 + ":\t\t" + "(" + rollvalues[i] + ")" + printX(rollvalues[i]));
                            }
                            if (numRolls == numRolls1) {
                                System.out.println("Dice " + highestDice + " is tied with Dice " + secondHighestDice);
                            } else {
                                System.out.println("The roll of " + highestDice + " wins!");
                                System.out.println("It was rolled " + numRolls + " time(s)!");
                                //printing out the table of odds and histogram
                                if (rollBet == highestDice) {
                                    if (rollBet == 2 || rollBet == 12) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() +
                                                (int) (36 * Math.pow(1.0 + ((3 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (36 * Math.pow(1.0 + ((3 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    } else if (rollBet == 3 || rollBet == 11) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (int) (36 * Math.pow(1.0 + ((2 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (36 * Math.pow(1.0 + ((2 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    } else if (rollBet == 4 || rollBet == 10) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (int) (36 * Math.pow(1.0 + casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (36 * Math.pow(1.0 + casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    } else if (rollBet == 5 || rollBet == 9) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (9 * betAmount) - betAmount));
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (9 * betAmount) - betAmount));
                                        System.out.println(casino.toString());
                                    } else if (rollBet == 6) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (int) (7.2 * Math.pow(1.0 - casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (7.2 * Math.pow(1.0 - casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    } else if (rollBet == 7) {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (int) (6.0 * Math.pow(1.0 - ((2 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (6.0 * Math.pow(1.0 - ((2 * casino.CasinoFactor())), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    } else {
                                        privateGamblerName.setBalance((privateGamblerName.getEndBalance() + (int) (36 * Math.pow(1.0 - casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(privateGamblerName.toString());
                                        casino.setCasinoBalance((casino.getEndCasinoBalance() - (int) (36 * Math.pow(1.0 - casino.CasinoFactor(), rollsAmount)) * betAmount) - betAmount);
                                        System.out.println(casino.toString());
                                    }
                                    if (casino.getEndCasinoBalance() < 0) {
                                        System.out.println(casino.getCasinoName() + " is now bankrupt bye");
                                        System.exit(0);
                                    }
                                    s.nextLine();
                                    System.out.println("Would you like to make another bet? (3 for yes/4 for no): ");

                                    String yessNoo = s.nextLine();
                                    if (yessNoo.charAt(0) != '3') {
                                        keepPlaying = false;
                                    }
                                } else {


                                    casino.setCasinoBalance(casino.getEndCasinoBalance() + betAmount);
                                    System.out.println(casino.toString());
                                    privateGamblerName.setBalance(privateGamblerName.getEndBalance() - betAmount);
                                    System.out.println(privateGamblerName.toString());
                                    if (privateGamblerName.getEndBalance() < 10) {
                                        System.out.println("You need more money in your account balance, make a new account");
                                        keepPlaying = false;
                                    }

                                    System.out.println("Don't let the losing get you down, try again!\n");
                                    s.nextLine();
                                    System.out.println("Would you like to make another bet? (y/n): ");
                                    System.out.println("If you have less than 10 dollars enter anything but y to return to the main menu");

                                    String yesNo = s.nextLine();
                                    if (yesNo.charAt(0) != 'y') {
                                        keepPlaying = false;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    System.out.println(" Go make an account with a name ");
                }
            } else if (userSelection.equals("q")) {
                System.out.println("Goodbye!");
                System.exit(0);
            }
        }
    }

    public static String printX(int n) {
        String stringForX = "";
        for (int i = 0; i < n; i++) {
            stringForX += "X";
        }
        return stringForX;
    }


    public static void runMainMenu() {
        System.out.println("** Dice Odds Game Main Menu**");
        System.out.println("** Please type a menu option and press enter.**");
        System.out.println("1) Setup a new gambling account");
        System.out.println("2) Make a bet");
        System.out.println("q) Quit");
        System.out.print("Selection: ");
    }

    public static Gambler createGambler(Gambler privateGamblerName, Scanner s) {
        System.out.println("Please Enter your Name: ");
        String userName = s.nextLine();
        if (userName.length() == 0)
            System.out.println("Put in a name");
        System.out.println("Please Enter your Starting Balance ($10 Min and $100000 Max): ");
        int sBalance = s.nextInt();
        if (sBalance >= 10 && sBalance <= 100000) {
            privateGamblerName = new Gambler(userName, sBalance);
            System.out.println("Gambler created with name " + privateGamblerName.getName());
            System.out.println("Thank you, " + userName + ", for opening an account with us.\n" +
                    "\tWe hope your balance will soon be $0.\n");
        } else {
            System.out.println("$10 minimum and $100000 maximum ");
        }
        return privateGamblerName;
    }


}

