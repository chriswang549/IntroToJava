package part1;


public class PairOfDice {
    private Die die1 = new Die();
    private Die die2;

    public PairOfDice() {
        die2 = new Die();
    }

    public Die getDie1() {
        return die1;
    }

    public Die getDie2() {
        return die2;
    }

    public int getTotal() {
        return die1.getUpValue() + die2.getUpValue();
    }

    public void rollDice() {
        die1.roll();
        die2.roll();
    }
}



