package part1;

import java.awt.*;

//  public void sortBoxes(ColoredBox[] boxes) {
//        int i,j;
//        // number mod 10 = ones digit
//        // number /10 mod 10 = 2nd digit
//        // n
//        // [55,203,9]
//        int [] onesArray = new int [boxes.length];
//        int [] tensArray = new int [boxes.length];
//        int [] hundredsArray = new int [boxes.length];
//        for (i=0; i<boxes.length;i++ ){
//           ColoredBox temp = boxes[i];
//           int onesValue = boxes[i].getNum()%10;
//           int tensValue = (boxes[i].getNum() / 10) % 10;
//           int hundValue = boxes[i] . getNum() % 100;
//           for(j=0 ; j<boxes.length; j++)
//           onesArray[j] = onesValue;
//            //create array 256 , loop thru all boxes, 0-256
//
//        }
//
//
//    }
//}
public class RadixSortBoxSorter implements BoxSorter {
    @Override
    public void sortBoxes(ColoredBox[] boxes) {
        int i, j, k, x, y, z;


        // make new array 0-255        array is full of 0's
        // new final array with boxes.length

        // Boxes
        // [ 1, 0 , 0 , 4]

        // Occurences
        // 0,1,2,3,4       0 1 2 3 4
        //[0,0,0,0,0] => [2,1,0,0,1]
        // first for loop
        // sort through all Boxes and get value of Boxes of all indexes
        //occurences at index value increment b/c its like a counter

        //2nd for loop
        //counting variable
        // for i  occurences find the value of occurences at each index
        // valueAtIndex = 2
        //finalArray[0] = 0 , finalArray[1] = 0, break out of j loop
        // valueAtIndex = 1
        // finalArray[2] = 1
        // finalArray = [0,0,1  ]
        //3rd for loop
        //sort through the final array
        // new coloredbox array taking in [0,0,1,4]
        // our boxes values at each index = values of final array which is [0,0,1,4]
        int[] occurences = new int[256];
        int[] finalArray = new int[boxes.length];


        for (y = 0; y < boxes.length; y++) {
            int value = boxes[y].getNum();
            ++occurences[value];


        }
        int track = 0;
        for (i = 0; i < occurences.length; i++) {
            int valueAtIndex = occurences[i];
            for (j = 0; j < valueAtIndex; j++) {
                finalArray[track] = i;
                track++;
            }
        }
        for (i = 0; i < finalArray.length; i++) {
            ColoredBox wt = new ColoredBox(finalArray[i], new Color(finalArray[i], 0, 0));
            boxes[i] = wt;
            BoxSortingDemo.updateDisplay();

        }
    }
}


