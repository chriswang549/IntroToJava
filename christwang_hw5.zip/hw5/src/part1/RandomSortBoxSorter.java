package part1;

import javax.swing.*;

public class RandomSortBoxSorter implements BoxSorter {
    @Override
    public void sortBoxes(ColoredBox[] boxes) {
        int i, j, minValueAtIndex;

        while (!checkIfSorted(boxes)) {
            for (i = 0; i < boxes.length - 1; i++) {
                if (boxes[i].compareTo(boxes[i + 1]) == 1) {

                    int randomIndex = (int) ((Math.random()) * boxes.length); //   values of 0 to length-1 because index 0-4 assuming length = 5

                    ColoredBox temp = boxes[i];
                    boxes[i] = boxes[randomIndex];

                    boxes[randomIndex] = temp;
                    BoxSortingDemo.updateDisplay();
                }

                }
            }
        }


    private static boolean checkIfSorted(ColoredBox[] boxes) {
        for (int i = 0; i < boxes.length; i++) {
            if (boxes[i].compareTo(boxes[i + 1]) == -1) {
                return false;
            }
        }
        return true;
    }

}

