package part1;
//public class BubbleSortBoxSorter implements BoxSorter {
//   @Override
//   public void sortBoxes(ColoredBox[] boxes) {
//
//int i, j;
//
//
//       for(i = 0; i < boxes.length; i++) {
//           for(j = 0; j < boxes.length-1; j++) {
//               if (boxes[j].compareTo(boxes[j+1]) == 1) {
//                   ColoredBox temp = boxes[j];
//                   boxes[j] = boxes[j+1];
//                   boxes[j+1] = temp;
//                  BoxSortingDemo.updateDisplay();}}}}}


public class BubbleSortBoxSorter implements BoxSorter {
    @Override
    public void sortBoxes(ColoredBox[] boxes) {

        int i, j;


        for(i = boxes.length -1; i >= 0; i--) {
            for(j = boxes.length-1; j >0; j--) {
                while (boxes[j].compareTo(boxes[j-1]) == -1) {
                    ColoredBox temp = boxes[j-1];
                    boxes[j-1]= boxes[j];
                    boxes[j] = temp;
                    BoxSortingDemo.updateDisplay();
            }
        }
    }
}}