package part1;

import java.awt.*;

// normal selection sort starting at index 0, length of length-2 b/c initial swap - 1 and nothing to right of last index -1
// so i <= increment by 1)

// set the minValue at index to the first index so 0 and etc

// check the next index j= i+1 , length of length - 1 b/c it always starts at index 1 what is left is length-1 values)
// if the value of j = [i+1] is less than our minValue at index
// our new minValue at index => j = i+1

// we swap the  old minValue at index = i (data[i]) with the new minValue at index by
// creating a temporary variable for the old minValue at index = i  0 in the first swap
// setting the index at [i] with the new min Value Index value
// setting the newMinValue index value with the old min value index of [i]
// swap done
// repeat starting with i = 1 and repeat until length

//public void sortBoxes(ColoredBox[] boxes) {
//        int i, j, minValueAtIndex;
//        for (i = 0; i < boxes.length-1; i++) {
//            minValueAtIndex = i;
//            for (j = i + 1; j < boxes.length; j++)
//                if (boxes[j].compareTo(boxes[minValueAtIndex] )== -1)
//                    minValueAtIndex = j;
//
//            ColoredBox temp = boxes[i];
//            boxes[i] = boxes[minValueAtIndex];
//            boxes[minValueAtIndex] = temp;
//            BoxSortingDemo.updateDisplay();
//        }
//
//    }}
// smallest to the right largest - smalelst
//   public void sortBoxes(ColoredBox[] boxes) {
//        int i, j, minValueAtIndex;
//        for (i = boxes.length - 1; i >=0 ; i--) {
//            minValueAtIndex = i;
//            for (j = i - 1; j >=0; j--)
//                if (boxes[j].compareTo(boxes[minValueAtIndex] )== -1)
//                    minValueAtIndex = j;
//
//            ColoredBox temp = boxes[i];
//            boxes[i] = boxes[minValueAtIndex];
//            boxes[minValueAtIndex] = temp;
//            BoxSortingDemo.updateDisplay();
//        }
//
//    }}

/**
 * YOU MUST DEFINE THIS CLASS
 *
 * This class provides a reverse implementation
 * of the selection sort algorithm.
 *
 * @author _____________
 */
public class SelectionSortBoxSorter implements BoxSorter
{

    public void sortBoxes(ColoredBox[] boxes) {
       int i, j, minValueAtIndex;
       for (i = boxes.length-1; i >= 0; i--) {
           minValueAtIndex = i;
           for (j = i - 1; j >=0 ; j--)
               if (boxes[minValueAtIndex].compareTo(boxes[j] )== -1)
                  minValueAtIndex = j;

           ColoredBox temp = boxes[i];
           boxes[i] = boxes[minValueAtIndex];
           boxes[minValueAtIndex] = temp;
         BoxSortingDemo.updateDisplay();
      }

   }}


