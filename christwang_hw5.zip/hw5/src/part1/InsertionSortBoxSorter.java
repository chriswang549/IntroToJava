package part1;
// Insertion sort starts at  i = 1 since we check from the value to the left => nothing on the left of the first index
// data.length - 1  or just length??? test
// increment i
// minValue at index is i = 1 at the start. We use this like a key so we can check values on the left
// j = i - 1 checking the value on the left

import java.awt.*;

//while    j is greater than or equal to 0 => j = 1- 1 = 0         and the min value at index = i less than i -1
// keep swapping creating temp variable for [j] or [i-1]
// setting [j] to [j+1]
// j+1 becomes the temp variable so swap is done
// j-- and we go through the array from right to left
//      int i,j, minValueAtIndex;
//
//public class InsertionSortBoxSorter implements BoxSorter {
//    @Override
//    public void sortBoxes(ColoredBox[] boxes) {
//        int i, j;
//
//        for (i = 1; i < boxes.length; i++) {
//            for (j = 0; j < i; j++) {
//                if (boxes[i].compareTo(boxes[j]) == -1) {
//                    ColoredBox temp = boxes[i];
//                    for (int k = i; k > j; k--) {
//                        boxes[k] = boxes[k - 1];
//                    }
//                    boxes[j] = temp;
//                    BoxSortingDemo.updateDisplay();
//                }
//            }
//        }
//    }
//}



public class InsertionSortBoxSorter implements BoxSorter {
    @Override
    public void sortBoxes(ColoredBox[] boxes) {
        int i, j;

        for (i = boxes.length - 2; i >= 0; i--) {
            if (boxes[i].compareTo(boxes[i + 1]) == 1) {
                ColoredBox temp = boxes[i];
                int counter = i + 1;
                while (counter < boxes.length && boxes[counter].getNum() < temp.getNum()) {
                    boxes[counter - 1] = boxes[counter];
                    counter++;
                }
                boxes[counter-1] = temp;
                BoxSortingDemo.updateDisplay();
            }
        }
        BoxSortingDemo.updateDisplay();
    }

}