package part1;

/**
 * Students should define the isValidIpAddress and generateRandomIpAddress
 * methods for Part 1 of HW 2. Note that you may (and should) add whatever
 * additional methods you like to help these two required methods perform
 * their intended function. Such additional methods are called helper methods
 * because they help other methods work properly.
 *
 * @author Christopher Wang
 */
public class IpAddressVerifier {
    /**
     * YOU MUST DEFINE THIS METHOD - YOU MAY ADD HELPER METHODS
     * <p>
     * isValidIpAddress - This method should examine the testIpAddress
     * method argument and determine if it is in the proper format. If it
     * is, return true, otherwise return false;
     */
    public static boolean isValidIpAddress(String testIpAddress) {


        //int x = Integer.parseInt(testIpAddress);
        if (!testIpAddress.contains(".") || testIpAddress.length() > 15 || testIpAddress.length() < 7)
            return false;


        try {       // check index up to "." and delete and start from there
            // check each index
            String FirstDot = testIpAddress.substring(0, testIpAddress.indexOf("."));
            int firstdotint = Integer.parseInt(FirstDot);
            if ((firstdotint < 0) || (firstdotint > 255)) {
                return false;
            }
            testIpAddress = testIpAddress.substring(testIpAddress.indexOf(".") + 1);
            String SecondNums = testIpAddress.substring(0, testIpAddress.indexOf("."));

            int SecondNumsInt = Integer.parseInt(SecondNums);
            if ((SecondNumsInt < 0) || (SecondNumsInt > 255)) {
                return false;
            }
            testIpAddress = testIpAddress.substring(testIpAddress.indexOf(".") + 1);
            String ThirdNums = testIpAddress.substring(0, testIpAddress.indexOf("."));
            int ThirdNumsInt = Integer.parseInt(ThirdNums);
            if ((ThirdNumsInt < 0) || (ThirdNumsInt > 255)) {
                return false;
            }
            testIpAddress = testIpAddress.substring(testIpAddress.indexOf(".") + 1);
            String FourthNums = testIpAddress;
            int FourthNumsInt = Integer.parseInt(FourthNums);
            if ((FourthNumsInt < 0) || (FourthNumsInt > 255)) {
                return false;
            }
        } catch(NumberFormatException McKillaGorilla){
            return false;
        }

        return true;

        // given user input , max length = 15 and min length= 7 greater and le-ss than = not valid,
        // index of "." but theres 3? so if index is 3 2 1 its valid
        //
        // ADD YOUR CODE HERE
    }

    /**
     * YOU MUST DEFINE THIS METHOD - YOU MAY ADD HELPER METHODS
     * <p>
     * generateRandomIpAddress - This method should randomly generate and
     * then return a String storing a textual representation of an
     * IP Address in the format of Num.Num.Num.Num, where each Num is
     * and integer from 0 - 255 inclusive.
     */
    public static String generateRandomIpAddress () {
        int randomnumber1 = (int) (Math.random() * 256);
        int randomnumber2 = (int)(Math.random() *256);
        int randomnumber3 = (int)(Math.random() *256);
        int randomnumber4 = (int)(Math.random() *256);
        return(randomnumber1 + "." + randomnumber2 + "." + randomnumber3
                + "." + randomnumber4);



    }
}

// YOU MAY ADD HELPER METHODS AS NEEDED
