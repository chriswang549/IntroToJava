package part2;

import java.time.Duration;
import java.time.LocalTime;
import java.text.NumberFormat;
import java.util.Scanner;

public class TimeTestDriver {

    public static void main(String[] args) {
        System.out.println("Hey! It's Christopher Wang's Program For Typing Speed. Shoutout to McKillaGorilla! ");

        double highScore = 0;

        Scanner s = new Scanner(System.in);
        while (true) {
            System.out.println("*** GAME MENU ***");
            System.out.println("(p) play another round");
            System.out.println("(x) exit the game");
            System.out.print("Selection: ");
            String userInput = s.nextLine();
            if (userInput.equals("p")) {
                String word = generateWord();
                System.out.println("Text to Match: " + word);
                LocalTime timeNow = LocalTime.now();
                userInput = s.nextLine();
                if (userInput.equals(word)) {
                    LocalTime timeAfter = LocalTime.now();
                    System.out.println(timeNow);
                    System.out.println(timeAfter);


                    Duration duration = Duration.between(timeNow, timeAfter);
                    long nanosecondsElapsed = duration.toNanos();
                    double executionTime = nanosecondsElapsed / 1000000000.0;
                    executionTime = executionTime / 60;
                    double cpm = userInput.length() / executionTime;
                    NumberFormat lol = NumberFormat.getInstance();
                    lol.setMaximumFractionDigits(1);
                    System.out.println("Speed:  " + lol.format(cpm) + " characters per minute.");

                    if (cpm > highScore) {
                        highScore = cpm;
                        System.out.println(" NEW FASTEST TYPING SPEED!");
                    } else {
                        System.out.println("NEED 4 SPEED ");
                    }

                } else {
                    System.out.println("INCORRECTLY TYPED, YOU GET A SPEED OF 0!");
                }
            } else if (userInput.equals("x")) {
                System.out.println("Goodbye!");
                System.exit(0);
            }
        }
    }



    public static String generateWord() {
        StringBuilder s = new StringBuilder();
        char c;
        int length = ((int) ((Math.random() * 30) + 10));
        for (int i = 0; i < length; i++) {
            c = ((char) ('a' + (Math.random() * 26)));
            s.append(c);
        }
        return s.toString();
    }
}