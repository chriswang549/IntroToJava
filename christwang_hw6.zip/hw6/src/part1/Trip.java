package part1;

import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Collection;

public class Trip {

    static ArrayList<String> stopsInTrip = new ArrayList<String>();
    static ArrayList<String> possibleStops = new ArrayList<String>();
    static DataOutputStream binfile = null;
    static PrintWriter pw = null;
    static File newFile = new File("PossibleStops.txt");
    static String tripName = "";
    // static String latitudeDegFiller = "";
    static int latitudeDeg = 0;
    static int latitudeMin = 0;
    static int longitudeDeg = 0;
    static int longitudeMin = 0;


    static FileOutputStream fos = null;

    double RADIAN_FACTOR = 180 / Math.PI;

    public static void main(String[] args) throws IOException {
        Scanner s = new Scanner(System.in);
        boolean runCode = true;


        if (!newFile.exists()) {
// THE FILE DOESN'T EXIST SO CREATE IT, OTHERWISE WE'LL HAVE TO LOAD IT

            FileWriter fw = new FileWriter(newFile.getAbsoluteFile());

            pw = new PrintWriter(fw);

            pw.write("Chicago ~ 41° ~ 53' ~ N ~ 87° ~ 38' ~ W\n" +
                    "Dallas ~ 32° ~ 51' ~ N ~ 96° ~ 51' ~ W\n" +
                    "Detroit ~ 42° ~ 25' ~ N ~ 83° ~ 1' ~ W\n" +
                    "Houston ~ 29° ~ 59' ~ N ~ 95° ~ 22' ~ W\n" +
                    "Los Angeles ~ 33° ~ 56' ~ N ~ 118° ~ 24' ~ W\n" +
                    "New York City ~ 40° ~ 47' ~ N ~ 73° ~ 58' ~ W\n" +
                    "Philadelphia ~ 39° ~ 53' ~ N ~ 75° ~ 15' ~ W\n" +
                    "Phoenix ~ 33° ~ 26' ~ N ~ 112° ~ 1' ~ W\n" +
                    "San Antonio ~ 29° ~ 32' ~ N ~ 98° ~ 28' ~ W\n" +
                    "San Diego ~ 32° ~ 44' ~ N ~ 117° ~ 10' ~ W\n");
            pw.close();


            //FileOutputStream file = new FileOutputStream("TripList");

            System.out.println(" Welcome to the list of Possible Stops for Trips");
            BufferedReader bufferedReader = null;
            bufferedReader = new BufferedReader(new FileReader(newFile));

            String read;
            while ((read = bufferedReader.readLine()) != null) {
                possibleStops.add(read);

// File f = new File(path);


                //String path = "C:\\Users\\Chris Wangs Surface3\\Desktop\\CSE 114\\hw6\\src\\TripList";
                // FileOutputStream file = new FileOutputStream(new File(path), true);
                // PrintWriter printWriter = null;
                // System.out.println(" Welcome to the list of Possible Stops for Trips");

                //BufferedReader bufferedReader = null;
                //bufferedReader = new BufferedReader(new FileReader(path));
                //String read;

            }
        } else {
            BufferedReader bufferedReader = null;
            bufferedReader = new BufferedReader(new FileReader(newFile));
            String read;
            while ((read = bufferedReader.readLine()) != null) {
                possibleStops.add(read);

            }
        }

        while (runCode) {

            runMainMenu();
            String userSelection = s.nextLine();

            String str = "";

            if (userSelection.equals("1")) {
                if (binfile == null) {
                    System.out.println("Enter a name for your trip:");
                    tripName = s.nextLine();
                    binfile = new DataOutputStream(new FileOutputStream(tripName));
                    // Ask to save or something
                } else {
                    System.out.println("You are currently working on a Trip, are you sure you want to create a new one?");
                    String ans = s.nextLine();
                    if (ans.equalsIgnoreCase("y")) {
                        // Ask to save or something
                        stopsInTrip = new ArrayList<>();
                        System.out.println("Enter a name for your trip:");
                        String tripName = s.nextLine();
                        binfile = new DataOutputStream(new FileOutputStream(tripName));
                    }
                }
            } else if (userSelection.equals("2")) {
                System.out.println("Enter the name of the trip file you want to load: ");
                String loadFile = s.nextLine();
                File open = new File(loadFile);
                if (!open.exists()) {
                    System.out.println("The trip file does not exist.");
                } else {
                    tripName = loadFile;
                    stopsInTrip = new ArrayList<>();
                    DataInputStream infile = new DataInputStream(new FileInputStream(open));
                    while (infile.available() > 0) {
                        String k = infile.readUTF();
                        stopsInTrip.add(k);
                    }
                    binfile = new DataOutputStream(new FileOutputStream(open));
                }
            } else if (userSelection.equals("3")) {
                Scanner d = new Scanner(System.in);

                System.out.println("Enter a city to add to the list of possible stops");
                String pickCityStop = s.nextLine();
                boolean notTrue = false;

                // scanner input pick citystop equals possibleStops.get(i).split("~")[0].trim();


                while (!notTrue) {
                    for (int i = 0; i < possibleStops.size(); i++) {
                        if (!pickCityStop.equalsIgnoreCase(possibleStops.get(i).split("~")[0].trim())) {


                        } else
                            while (pickCityStop.equalsIgnoreCase(possibleStops.get(i).split("~")[0].trim())) {
                                System.out.println("Enter a new city to list of possible stops");
                                pickCityStop = s.nextLine();
                                if (!pickCityStop.equalsIgnoreCase(possibleStops.get(i).split("~")[0].trim()))
                                    notTrue = true;

                            }
//                            System.out.println("You added a city to the list !");


                    }
                    notTrue = true;


                }


                // next line convert it to ints put try catch parse int
                String latitudeDegFiller = "";
                boolean isValid = false;
                while (!isValid) {

                    System.out.println("Enter a latitude in degrees");
                    latitudeDegFiller = s.nextLine();

                    try {
                        latitudeDeg = Integer.parseInt(latitudeDegFiller);
                        if (latitudeDeg <= 90 && latitudeDeg >= 0)
                            isValid = true;
                    } catch (Exception e) {
                        //
                    }
                }


                //       //while (latitudeDeg > 90 || latitudeDeg < 0) {
                //                //                    System.out.println("Pick a latitude between 0 to 90 degrees ");
                //                //                    latitudeDeg = s.nextInt();
                //                //                }


                String latitudeMinFiller = "";
                boolean isValid1 = false;
                while (!isValid1) {
                    System.out.println("Enter a latitude in minutes");
                    latitudeMinFiller = s.nextLine();


                    try {

                        latitudeMin = Integer.parseInt(latitudeMinFiller);

                        System.out.println(latitudeMin);
                    } catch (Exception e) {
                        continue;
                    }
                    if (latitudeMin <= 60 && latitudeMin >= 0)
                        isValid1 = true;


                }


                System.out.println("Enter a direction for latitude");

                String latDirection = s.nextLine();
                try {
                    while (!(latDirection.equalsIgnoreCase("N") || latDirection.equalsIgnoreCase("S"))) {
                        System.out.println("Pick a direction for latitude N or S");
                        latDirection = s.nextLine();
                    }
                } catch (Exception e) {
                    System.out.println("Wrong Input");
                }


                String longitudeDegFiller = "";
                boolean isValid2 = false;
                while (!isValid2) {
                    System.out.println("Enter a longitude in degrees");
                    longitudeDegFiller = s.nextLine();


                    try {

                        longitudeDeg = Integer.parseInt(longitudeDegFiller);

                        System.out.println(longitudeDeg);
                    } catch (Exception e) {
                        continue;
                    }
                    if (longitudeDeg <= 180 && longitudeDeg >= 0)
                        isValid2 = true;


                }


                String longitudeMinFiller = "";
                boolean isValid3 = false;
                while (!isValid3) {
                    System.out.println("Enter a longitude in minutes");
                    longitudeMinFiller = s.nextLine();


                    try {

                        longitudeMin = Integer.parseInt(longitudeMinFiller);

                        System.out.println(longitudeMin);
                    } catch (Exception e) {
                        continue;
                    }
                    if (longitudeMin <= 60 && longitudeMin >= 0)
                        isValid3 = true;


                }
                System.out.println("Enter a direction for longitude");
                String longDirection = s.nextLine();
                while (!(longDirection.equalsIgnoreCase("W") || longDirection.equalsIgnoreCase("E"))) {
                    System.out.println("Pick a direction for longitude W or E");
                    longDirection = s.nextLine();
                }
                String line = pickCityStop + " ~ " + latitudeDeg + "° ~ " + latitudeMin +
                        "' ~ " + latDirection + " ~ " + longitudeDeg + "° ~ " + longitudeMin + "' ~ " + longDirection;
                possibleStops.add(line);

                Collections.sort(possibleStops, String.CASE_INSENSITIVE_ORDER);
                printPossibleStops();
                printStopsInTrip();

            } else if (userSelection.equals("4")) {
                //i don't actually need to have a trip to modify stops list
                System.out.println("Enter a city to remove");
                String removeCityStop = s.nextLine();
                boolean found = false;
                for (int i = 0; i < possibleStops.size(); i++) {
                    String removeCity = possibleStops.get(i).split("~")[0].trim();
                    if (removeCity.equalsIgnoreCase(removeCityStop)) {
                        possibleStops.remove(possibleStops.get(i));
                        System.out.println(removeCityStop + " removed from possible trips");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("City not found ");

                }
                printPossibleStops();
                printStopsInTrip();


            } else if (userSelection.equals("5")) {
                if (binfile == null) {
                    System.out.println("Please create or load a Trip file first");
                } else {
                    System.out.println("Enter the stop from the list of possible stops to add into the list of stops for trip");
                    String pickCityStopR = s.nextLine();
                    boolean found = false;
                    for (int i = 0; i < possibleStops.size(); i++) {
                        String city = possibleStops.get(i).split("~")[0].trim();

                        if (city.equalsIgnoreCase(pickCityStopR)) {
                            stopsInTrip.add(possibleStops.get(i));
                            System.out.println(pickCityStopR + " added to the trip");
                            found = true;
                            break;
                        }
                        // calculateDistance(pickCity)
                    }
                    if (!found) {
                        System.out.println("City not found ");

                    }
                    printPossibleStops();
                    printStopsInTrip();
                }


            } else if (userSelection.equals("6")) {
                if (binfile == null) {
                    System.out.println("Please create or load a Trip file first");
                } else {
                    System.out.println("Pick a stop to insert to trip list from possible stops");
                    String insertStopsToTrips = s.nextLine();

                    boolean found = false;
                    for (int i = 0; i < possibleStops.size(); i++) {
                        String insertCity = possibleStops.get(i).split("~")[0].trim();
                        if (insertCity.equalsIgnoreCase(insertStopsToTrips)) {
                            found = true;
                            System.out.println("What stop number should this be?");
                            int stopNumber = Integer.parseInt(s.nextLine());
                            if (stopNumber < 1 || stopNumber > stopsInTrip.size() + 1) {
                                // error
                            } else
                                stopsInTrip.add(stopNumber - 1, possibleStops.get(i));
                            break;
                        }
                    }

                    if (!found) {
                        System.out.println("City not found ");

                    }
                    printPossibleStops();
                    printStopsInTrip();


                }
            } else if (userSelection.equals("7")) {
                if (binfile == null) {
                    System.out.println("Please create or load a Trip file first");
                } else {
                    System.out.println("Remove a stop from stops for a trip");
                    String removeTripCity = s.nextLine();
                    boolean foundA = false;
                    for (int i = 0; i < stopsInTrip.size(); i++) {
                        String removeTrip = stopsInTrip.get(i).split("~")[0].trim();
                        if (removeTrip.equalsIgnoreCase(removeTripCity)) {
                            stopsInTrip.remove(stopsInTrip.get(i));
                            System.out.println(removeTripCity + " removed from the trip");
                            foundA = true;
                            break;
                        }
                    }
                    if (!foundA) {
                        System.out.println("City not found ");

                    }
                    printPossibleStops();
                    printStopsInTrip();


                }
            } else if (userSelection.equalsIgnoreCase("q")) {
                //System.out.println(possibleStops);
                // Ask user if he wants to save the trip
                pw = new PrintWriter(newFile);


                for (int k = 0; k < possibleStops.size(); k++) {
                    String printing = "";
                    printing += possibleStops.get(k);
                    pw.write(printing + "\n");
                }
                pw.close();

                if (!tripName.isEmpty()) {
                    File newTrip = new File(tripName);

                    FileOutputStream file = new FileOutputStream(newTrip);

                    try {
                        binfile = new DataOutputStream(file);
                        for (int z = 0; z < stopsInTrip.size(); z++) {
                            binfile.writeUTF(stopsInTrip.get(z));
                        }
                        binfile.close();
                    } catch (IOException ioe) {
                        System.out.println("Error");
                    }
                    boolean stop = false;
                    double distance = 0;
                    if (stopsInTrip.size() > 1) {
                        for (int i = 0; i < stopsInTrip.size(); i++) {
                            int lat1Degrees = Integer.parseInt(stopsInTrip.get(i).split("~")[1].trim().replace("°", ""));
                            int lat1Minutes = Integer.parseInt(stopsInTrip.get(i).split("~")[2].trim().replace("'", ""));
                            String lat1Direction = stopsInTrip.get(i).split("~")[3].trim();
                            System.out.println(lat1Direction);
                            int long1Degrees = Integer.parseInt(stopsInTrip.get(i).split("~")[4].trim().replace("°", ""));
                            int long1Minutes = Integer.parseInt(stopsInTrip.get(i).split("~")[5].trim().replace("'", ""));
                            String long1Direction = stopsInTrip.get(i).split("~")[6].trim();
                            System.out.println(long1Direction);

                            int lat2Degrees = Integer.parseInt(stopsInTrip.get(i + 1).split("~")[1].trim().replace("°", ""));
                            int lat2Minutes = Integer.parseInt(stopsInTrip.get(i + 1).split("~")[2].trim().replace("'", ""));
                            String lat2Direction = stopsInTrip.get(i + 1).split("~")[3].trim();
                            System.out.println(lat2Direction);
                            int long2Degrees = Integer.parseInt(stopsInTrip.get(i + 1).split("~")[4].trim().replace("°", ""));
                            int long2Minutes = Integer.parseInt(stopsInTrip.get(i + 1).split("~")[5].trim().replace("'", ""));
                            String long2Direction = stopsInTrip.get(i + 1).split("~")[6].trim();
                            System.out.println(long2Direction);
                            distance += calculateDistance(lat1Degrees, lat1Minutes, long1Degrees, long1Minutes,
                                    lat2Degrees, lat2Minutes, long2Degrees, long2Minutes, lat1Direction, long1Direction, lat2Direction, long2Direction);
                            System.out.println(distance);

                            break;
                        }
                        System.out.println("Total distance is displayed!");
                    } else if (stopsInTrip.size() == 1) {


                        distance = 0;
                        System.out.println("You have one stop so the distance between two or more stops = 0");
                        System.out.println(distance);


                        System.out.println("Total distance has been calculated");
                    } else {
                        System.out.println("You have no stops in your trip");
                    }

                    System.exit(0);
                } else {
                    System.out.println("Good Bye");
                    System.exit(0);
                }

            } else if (userSelection.equalsIgnoreCase("p")) {
                System.out.println("List of Possible Stops:");
                printPossibleStops();
                System.out.println("List of Stops Currently in Trip:");
                printStopsInTrip();

            }
        }
    }

    public static void printStopsInTrip() {
        for (int i = 0; i < stopsInTrip.size(); i++) {
            System.out.println(stopsInTrip.get(i));
        }
        System.out.println();
    }

    public static void printPossibleStops() {
        for (int i = 0; i < possibleStops.size(); i++) {
            System.out.println(possibleStops.get(i));
        }
        System.out.println();
    }

    public static void runMainMenu() throws IOException {
        System.out.println("** Please type a menu option and press enter.**");
        System.out.println("1) Create A New Trip File");
        System.out.println("2) Load A Trip File");
        System.out.println("3) Append A Stop To The List of Possible Stops"); //add array list -> text

        System.out.println("4) Remove A Stop From List of Possible Stops");   //remove
        System.out.println("5) Append A Stop To Current Trip");
        System.out.println("6) Insert A Stop To Current Trip");
        System.out.println("7) Remove A Stop From Current Trip");

        System.out.println("p) Print Possible Stops and Stops for Trip");
        System.out.println("q) Quit");
        System.out.print("Selection: ");
    }


    private static double calculateDistance(double lat1Degrees, double lat1Minutes,
                                            double lat2Degrees, double lat2Minutes,
                                            double long1Degrees, double long1Minutes, double long2Degrees, double long2Minutes, String
                                                    lat1direction, String long1Direction, String lat2direction, String long2direction) {

        double RADIAN_FACTOR = 180 / Math.PI;
        double lat1 = 0;  // Multiple by direction 1 or -2
        double lat2 = 0;
        double long1 = 0;
        double long2 = 0;
        int EARTH_RADIUS = 6371;

        double latitude1Direction = 0;
        double longitude1Direction = 0;
        double latitude2Direction = 0;
        double longitude2Direction = 0;

        if (lat1direction.equalsIgnoreCase("S")) {
            lat1 = (lat1Degrees + lat1Minutes / 60) * (-1);
        } else {
            lat1 = lat1Degrees + lat1Minutes / 60;
        }
        if (lat2direction.equalsIgnoreCase("S")) {
            lat2 = (lat2Degrees + lat2Minutes / 60) * (-1);

        } else {
            lat2 = lat2Degrees + lat2Minutes / 60;
        }
        if (long1Direction.equalsIgnoreCase("W")) {
            long1 = (long1Degrees + long1Minutes / 60) * (-1);
        } else {
            long1 = (long1Degrees + long1Minutes / 60);
        }
        if (long2direction.equalsIgnoreCase("W")) {
            long2 = (long2Degrees + long2Minutes / 60) * (-1);
        } else {
            long2 = (long2Degrees + long2Minutes / 60);
        }


        double x = (Math.sin(lat1 / RADIAN_FACTOR) * Math.sin(lat2 / RADIAN_FACTOR))
                + (Math.cos(lat1 / RADIAN_FACTOR)
                * Math.cos(lat2 / RADIAN_FACTOR)
                * Math.cos((long2 / RADIAN_FACTOR) - (long1 / RADIAN_FACTOR)));

        double distance = EARTH_RADIUS * Math.atan((Math.sqrt(1 - Math.pow(x, 2)) / x));
        return distance;
    }
}